<?php include("includes/common.php");?>
<?php 

$username="";
$email="";
$city="";
$address="";
$phone="";

    if (isset($_POST['reg_user'])) {
        $isValid = true;
        $username = mysqli_real_escape_string($conn, $_POST['username']);
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        $phone = mysqli_real_escape_string($conn, $_POST['phone']);
        $password = mysqli_real_escape_string($conn, $_POST['password']);
        $city = mysqli_real_escape_string($conn, $_POST['city']);
        $address = mysqli_real_escape_string($conn, $_POST['address']);
      
        if (empty($username)) {
            $username_error = "Name is required";
            $isValid = false;
        }
        if(!filter_var($email,FILTER_VALIDATE_EMAIL)) {
            $email_error = "Please Enter Valid Email ID";
             $isValid = false;
        }     
        if(strlen($phone) != 10) {
            $phone_error = "Mobile number must be of 10 characters";
             $isValid = false;
        }
         if (empty($city)) {
            $city_error = "city is required";
              $isValid = false;
        }
         if (empty($address)) {
            $address_error = "address is required";
              $isValid = false;
        }
        $user_check_query = "SELECT * FROM users WHERE email='$email' LIMIT 1";
  $result = mysqli_query($conn, $user_check_query);
  $user = mysqli_fetch_assoc($result);
  
  if ($user) { // if user exists
    if ($user['email'] === $email) {
       $email_error =  "Email  already exists";
        $isValid = false;
    }

  }
        if ($isValid) {
            if(mysqli_query($conn, "INSERT INTO users(name, email, password,contact,city,address) VALUES('" . $username . "', '" . $email . "','" . md5($password) . "', '" . $phone . "','" . $city . "','" . $address . "' )")) {
                $_SESSION['loggedin'] = true;
             header("location: home.php");
             exit();
            } else {
               echo "Error: " . mysqli_error($conn);
            }
        }
        mysqli_close($conn);
    }
?>