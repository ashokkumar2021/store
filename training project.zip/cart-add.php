<?php 
   include('includes/common.php');
    $item_id = $_GET['id'];
    $user_id = $_SESSION['user_id'];
     $item_add_query = "INSERT INTO users_items(users_id, item_id, status) VALUES('$user_id', '$item_id', 'Added to cart')";
    $item_added = mysqli_query($conn, $item_add_query) or die(mysqli_error($conn));
    header('location:home.php');
?>