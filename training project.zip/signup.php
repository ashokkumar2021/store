<?php

if (isset($_SESSION['email'])) { 
    header('location: home.php'); } 
?> 
<?php include("signup_script.php");?>
<!DOCTYPE html>
<html>
  <head>
      <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
    <!--jQuery library--> 
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!--Latest compiled and minified JavaScript--> 
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>signup</title>
  </head>
<body>
   <?php include('includes/header.php');?>
    <div class="container" style="margin-top:40px;margin-bottom:24%;">
    <div class="col-md-6">
        <img src="abc.jpg" style="width:100%;height:auto;background-size:contain;margin-top:60px;">
        </div>
        <div class="col-md-6">
        <h3><strong>SIGN UP</strong></h3>
         <form action="signup.php" method="post">
      <div class="form-group">
      <input type="text" class="form-control" name="username" placeholder="Name" value="<?php echo $username; ?>"><span class="text-danger"><?php if (isset($username_error)) echo $username_error; ?></span>
    </div>
    <div class="form-group"> 
      <input type="text" class="form-control" name="email" placeholder="Email" value="<?php echo $email; ?>"><span class="text-danger"><?php if (isset($email_error)) echo $email_error; ?></span>
    </div>
    <div class="form-group">
      <input type="password" class="form-control" name="password" placeholder="Password">
    </div>
     <div class="form-group">
      <input type="number" class="form-control" name="phone" placeholder="Contact" value="<?php echo $phone; ?>"><span class="text-danger"><?php if (isset($phone_error)) echo $phone_error; ?></span>
    </div>
    <div class="form-group">
      <input type="text" class="form-control" name="city" placeholder="City" value="<?php echo $city; ?>"><span class="text-danger"><?php if (isset($city_error)) echo $city_error; ?></span>
    </div>
    <div class="form-group">
      <input type="text" class="form-control" name="address" placeholder="Address" value="<?php echo $address; ?>"><span class="text-danger"><?php if (isset($address_error)) echo $address_error; ?></span>
    </div>
			 <button  class="btn btn-primary" style="float:right" type="submit" name="reg_user">Submit</button>
  </form>
        </div>
    </div>
  <?php include('includes/footer.php');?>
  </body>
</html>