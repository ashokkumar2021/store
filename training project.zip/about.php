<!DOCTYPE html>
<html>
  <head>
      <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
    <!--jQuery library--> 
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!--Latest compiled and minified JavaScript--> 
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>About</title>
  </head>
<body>
    <?php
    include('includes/header.php');?>
    <div class="container" style="margin-top:60px;margin-bottom:24%">
    <div class="row">
        <div class="col-md-4">
            <h4>WHO WE ARE</h4>
            <img src="img/about.jpg" style="width:300px;height:200px;">
            <p>E - store is an Indian electronic commerce company  with headquarters in New Delhi.It is the largest internet-based retailer in the India.  E-store started as an online blog, but soon diversified , selling mobile phones.E-store also sells  certain other  low-end products like USB cable,earphones other  accessories. E-store has separate retail website for other countries as well . It offers international shipping to certain other countries.</p>
        </div>
        <div class="col-md-4">
            <h4>OUR HISTORY</h4>
            <p>1998-<br>The company was founded in 1998 , spurred by what jim called his  "initiating framework" ,which also described his efforts as an initiate to participate in the internet business boom during that time in 1998,jim left his employment as president of instacart and moved to Banglore . He began work on a business plan to what would eventually later to become E-store.<br><br>
            2002-<br>In January 2002,E-store has received a funding of $12 million from Venture Partners and Indo-US Venture Partners<br><br>2008-<br>In July 2008,the company further raised $45 million from Bessemer Venture Partners,along with existing investors Venture Partners and Indo-US Partners.<br><br>2019-<br>E-store received its 3rd round of funding of $133 million on Feb-2015. The 3rd round of funding was led by Fcom with all current institutional investors including Kallari Capital</p>
        </div>
        <div class="col-md-4">
            <h4>OPPORTUNITIES</h4>
            <p><strong>Available Roles</strong><br><br>1. Jr./Sr. Web Developer [full Time Role + also available as a 6 Months internship]<br><br>2.Business Apprentice [6 months internship]<br><br>3.Manager at backened operations  [full Time Role + also available as a 6 Months internship]</p>
        </div>      
        </div>
    </div>
  <?php
    include('includes/footer.php');?>
 </body>
</html>