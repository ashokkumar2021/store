<?php

session_start();
if(!isset($_SESSION['email'])){
    header('location:index.php');
    exit();
}
session_unset();
session_destroy();
header("Location:index.php");
?>
