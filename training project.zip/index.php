<?php
include('includes/common.php');
if (isset($_SESSION['email'])) { 
    header('location: home.php');
} 
?>
 
<!DOCTYPE html>
<html>
  <head>
      <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
    <!--jQuery library--> 
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!--Latest compiled and minified JavaScript--> 
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Homepage</title>
      <?php
      if(isset($_SESSION['login'])){
   echo   '<script type="text/javascript">';
   echo  "$(window).on('load',function(){
        $('#myModal').modal('show');
    });
</script>";}?>
      </head>
<body>
    <?php include('includes/header.php');?>
   <div class="container-fluid" style="margin-top:60px;margin-bottom:24%">
    <div class="row equal">
    <div class="col-md-4">
        <div class="panel panel-default">
                <div class="panel-heading">Apple Iphone 8
            </div>
                <div class="panel-body" >
                <img  src="img/apple-iphon%208.jpeg">
                    <p>256 GB ROM
13.97 cm (5.5 inch) Retina HD Display
12MP + 12MP | 7MP Front Camera
A11 Bionic Chip with 64-bit Architecture,Embedded M11 Motion Coprocessor Processor Rs.50000</p>
                    <a href="#myModal" data-toggle="modal" class="btn btn-block btn-primary">Order Now!</a>
            </div>
        </div>
        </div>
         <div class="col-md-4">
             <div class="panel panel-default">
                <div class="panel-heading">Samsung Galaxy S10
                 </div>
                <div class="panel-body">
                      <img  src="img/samsung-galaxy-s10-lite.jpeg"><p>8 GB RAM | 512 GB ROM | Expandable Upto 1 TB
17.02 cm (6.7 inch) Full HD+ Display
48MP + 12MP + 5MP | 32MP Front Camera
4500 mAh Lithium-ion Battery 
Qualcomm Snapdragon 855 (SM8150) Processor Rs.50000</p>
                    <a href="#myModal" data-toggle="modal" class="btn btn-block btn-primary">Order Now!</a>
            </div>
             </div>
        </div>
         <div class="col-md-4">
             <div class="panel panel-default">
                <div class="panel-heading">Apple Iphone XR
                 </div>
                <div class="panel-body">
                  <img  src="img/apple-iphone-xr.jpeg">
                    <p >64 GB ROM
15.49 cm (6.1 inch) Display
12MP Rear Camera | 7MP Front Camera
A12 Bionic Chip Processor
iOS 13 CompatibleGPU - 4-core, Graphics-intensive Gameplay Rs.80000</p>
                    <a href="#myModal" data-toggle="modal" class="btn btn-block btn-primary">Order Now!</a>
            </div>
               
        </div>
        </div>
        </div>
         <div class="row equal">
          <div class="col-md-4">
              <div class="panel panel-default">
                <div class="panel-heading">OPPO A12</div>
                <div class="panel-body">
                 <img  src="img/oppo-a12.jpeg"><p>3 GB RAM | 32 GB ROM | Expandable Upto 256 GB
15.8 cm (6.22 inch) HD+ Display
13MP + 2MP | 5MP Front Camera
4230 mAh Battery
MediaTek Helio P35 (MT6765V/CB) Processor
Rs. 10000</p>
                     <a href="#myModal" data-toggle="modal" class="btn btn-block btn-primary">Order Now!</a>
            </div>
              </div>
             </div>
              <div class="col-md-4">
                  <div class="panel panel-default">
                <div class="panel-heading">OPPO A5 2020</div>
                <div class="panel-body">
                 <img  src="img/oppo-a5-2020.jpeg"><p>3 GB RAM | 32 GB ROM | Expandable Upto 256 GB
15.75 cm (6.2 inch) HD+ Display
13MP + 2MP | 8MP Front Camera
4230 mAh L-ion Battery 
MTK MT6765   2 GHz Processor. Rs. 15000</p>
                    <a href="#myModal" data-toggle="modal" class="btn btn-block btn-primary">Order Now!</a>
            </div>
          </div>
        </div>
              <div class="col-md-4">
                  <div class="panel panel-default">
                <div class="panel-heading">OPPO F11</div>
                <div class="panel-body">
                     <img  src="img/oppo-f11-pro.jpeg"><p>6 GB RAM | 64 GB ROM | Expandable Upto 256 GB
16.51 cm ( 6.5 inch ) Full HD+ Display
48MP + 5MP | 16MP Front Camera
4000 mAh Li-polymer Battery
MediaTek Helio P70 Octa Core 2.1 GHz Processor
VOOC Charging
Pop-up Camera. Rs 18000</p>
                   <a href="#myModal" data-toggle="modal" class="btn btn-block btn-primary">Order Now!</a>
         </div>
        </div>
        </div>
        </div>    
    </div>
    <?php include('includes/footer.php');?>
  </body>
</html>