
<?php
    
function check_if_added_to_cart($item_id){
     $servername='localhost';
    $user='root';
    $password='';
    $dbname = "store";
     
    $conn=mysqli_connect($servername,$user,$password,"$dbname");
      if(!$conn){
          die('Could not Connect MySql Server:' .mysql_error());
        }
    $user_id = $_SESSION['user_id'];
      $query = "SELECT * FROM users_items WHERE item_id='$item_id' AND users_id ='$user_id' AND status='Added to cart'";
      $results = mysqli_query($conn, $query);
    if(mysqli_num_rows($results) >= 1) {
        return 1;
    }
    else{
        return 0;
    }
}
?>