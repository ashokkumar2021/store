<?php
include('includes/common.php');
if(!isset($_SESSION['email'])){
    header('location:index.php');
    exit();
}
?>


<!DOCTYPE html>
<html>
  <head>
      <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
    <!--jQuery library--> 
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!--Latest compiled and minified JavaScript--> 
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>success</title>
  </head>
<body>
<nav class="navbar navbar-default navbar-fixed-top">    
    <div class="container">      
        <div class="navbar-header">       
            <button type="button" class="navbar-toggle" data-toggle="collapse" datatarget="#myNavbar">      
                <span class="icon-bar"></span>    
                <span class="icon-bar"></span>    
                <span class="icon-bar"></span>    
            </button>           
            <a class="navbar-brand" href="index.php">Lifestyle Store</a>   
        </div>        
        <div class="collapse navbar-collapse" id="myNavbar">      
            <ul class="nav navbar-nav navbar-right">                       
                <li><a href = "settings.php"><span class = "glyphicon glyphicon-user"></span> Settings</a></li>    
                <li><a href = "logout_script.php"><span class = "glyphicon glyphicon-log-out"></span> Logout</a></li>                           
            </ul>     
        </div>   
    </div>
</nav>
  <?php
$user_id = $_SESSION['user_id'];
$confirm = mysqli_query($conn,"UPDATE users_items
SET status = 'Confirmed'
WHERE users_id = '$user_id'");
 echo '<div class="container" style="margin-top: 180px; text-align: center;">
       <h1> Your order is confirmed. </h1>
       <p> Thank you for shopping  with us <a href="home.php">Click here</a> to purchase any other item. </p>
    </div>';
?>
  </body>
</html>
