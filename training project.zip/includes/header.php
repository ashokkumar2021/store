<?php include('includes/common.php');?>
<nav class="navbar navbar-default navbar-fixed-top">    
    <div class="container">      
        <div class="navbar-header">       
            <button type="button" class="navbar-toggle" data-toggle="collapse" datatarget="#myNavbar">      
                <span class="icon-bar"></span>    
                <span class="icon-bar"></span>    
                <span class="icon-bar"></span>    
            </button>           
            <a class="navbar-brand" href="index.php">Lifestyle Store</a>   
        </div>        
        <div class="collapse navbar-collapse" id="myNavbar">      
            <ul class="nav navbar-nav navbar-right">      
                <?php                
                if (isset($_SESSION['email'])) {       
                ?>                
                <li><a href = "cart.php"><span class = "glyphicon glyphicon-shopping-cart"></span> Cart </a></li>   
                <li><a href = "settings.php"><span class = "glyphicon glyphicon-user"></span> Settings</a></li>    
                <li><a href = "logout_script.php"><span class = "glyphicon glyphicon-log-out"></span> Logout</a></li>                    
                <?php  
                } else { 
                ?>         
                 <li><a href="signup.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
                        <li><a href="#myModal" data-toggle="modal"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
                         <li><a href="about.php"><span class="glyphicon glyphicon-tasks"></span> About Us</a></li>
                         <li><a href="contact.php"><span class="glyphicon glyphicon-phone"></span> Contact Us</a></li>     
                <?php                  
                }                
                ?>            
            </ul>     
        </div>   
    </div>
</nav>
 <div class="modal" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header" style="padding-bottom: 5px">
       <h4 style="float: left"><strong>LOGIN</strong></h4>
        <button type="button" style="margin-top:  5px 0px; font-size: 24px;"class="close" data-dismiss="modal" onclick="<?php unset($_SESSION['login']);?>">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
       <p>Don't have an account?<a href="signup.php">Register</a></p> 
        <form action="login_submit.php" method="post">
            <span  class="text-danger"> <?php if(isset($_SESSION['error'])){ echo $_SESSION['error'];unset($_SESSION['error']);} ?></span>
               <div class="form-group">
                    <input class="form-control" type="email" placeholder="Email" name="email" value="<?php echo $email;?>"></div>
               <div class="form-group">
                   <input class="form-control" type="password" placeholder="Password" name="pwd"></div>
          <button type="submit" class="btn btn-primary" name="login_user">Login</button>           
          </form>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
       <a  href="#" style="float: left">Forgot Password?</a>
      </div>
</div>
  </div>
</div>
