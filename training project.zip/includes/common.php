<?php
session_start();
    $servername='localhost';
    $user='root';
    $password='';
    $dbname = "store";
    $name ="";
    $email ="";
    $password ="";
    $contact ="";
    $city ="";
    $address="";
    $oldpwd = "";
       $pwd_1 = "";
       $pwd_2 = "";
    
    $conn=mysqli_connect($servername,$user,$password,"$dbname");
      if(!$conn){
          die('Could not Connect MySql Server:' .mysql_error());
        }
?>