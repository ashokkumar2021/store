<div class="footer">
       <div class="row">
         <div class="col-md-4 col-sm-4 col-xs-4" col-sm-4 col-xs-4><h4>Information</h4>
             <a href="about.php">About Us</a><br>
                <a href="contact.php">Contact Us</a>
         </div>
    <div class="col-md-4 col-sm-4 col-xs-4"><h4>My Account</h4>
         <a href="#myModal" data-toggle="modal">Login</a><br>
         <a href="signup.php">Signup</a></div>
         <div class="col-md-4 col-sm-4 col-xs-4"><h4>Contact Us</h4><p>Contact +91-123-00000</p></div>
  </div>
</div>
 