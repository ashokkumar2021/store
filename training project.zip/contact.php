<!DOCTYPE html>
<html>
  <head>
      <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
    <!--jQuery library--> 
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!--Latest compiled and minified JavaScript--> 
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Contact</title>
  </head>
<body>
    <?php
    include('includes/header.php');
    ?>
    <div class="container" style="margin-top:70px;margin-bottom:24%">
    <div class="row">
        <div class="col-md-10">
           <h3>LIVE SUPPORT</h3>
            <h6>24 hours | 7 days a week | 365 days a year Live Technical Support</h6>
            <p>If you have any question feel free to write to us.We are happy to answer your questions as soon as possible.</p>
     </div>
        <div class="col-md-2 ">
       <img src="img/image2.png" style="background-size:cover;width:100%;">
        </div>
        </div>
        <div class="row">
        <div class="col-md-8">
      <form action="#">
  <div class="form-group">
    <label for="name">Name</label>
    <input type="email" class="form-control" id="name">
  </div>
  <div class="form-group">
    <label for="email">Email</label>
    <input type="email" class="form-control" id="email">
  </div>
  <div class="form-group">
  <label for="message">Message</label>
  <textarea class="form-control" rows="5" id="message"></textarea>
</div>
  <button type="submit" class="btn btn-primary">Submit</button>
</form>   
     </div>
        <div class="col-md-4" >
            <h3>Company Information :</h3>
            <p><strong>E-store pvt ltd</strong><br><br>
            75,cannaught place,south west delhi<br>
                New Delhi-110066<br>
                INDIA<br>ph : 011-25554546<br>Email : info@estore.com
            </p>
     
        </div>
    </div>
    </div>
<?php
    include('includes/footer.php');
    ?>
 </body>
</html>