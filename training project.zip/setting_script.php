
<?php
        if(isset($_POST['changepwd'])){
        $oldpwd = mysqli_real_escape_string($conn, $_POST['old_pwd']);
        $password_1 = mysqli_real_escape_string($conn, $_POST['pwd_1']);
        $password_2 = mysqli_real_escape_string($conn, $_POST['pwd_2']);
        $oldpwd = md5($oldpwd);
        if($password_1 != $password_2){
            $match_error = "Both passwords should be same";
        }
else{
    $result = mysqli_query($conn, "SELECT * from users WHERE email='" . $_SESSION["email"] . "'");
    $row = mysqli_fetch_array($result);
    if ($oldpwd == $row["password"]) {
        $password_1 = md5($password_1);
        mysqli_query($conn, "UPDATE users set password='$password_1' WHERE email='".$_SESSION["email"]."'");
        $message = "Password Changed";
    } else{
        $message = "Current Password is not correct";
    }
}
        }
?>
