<?php 
include('includes/common.php');
if(!isset($_SESSION['email'])){
  header('location:index.php');
}

?>

<!DOCTYPE html>
<html>
  <head>
      <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
    <!--jQuery library--> 
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!--Latest compiled and minified JavaScript--> 
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>cart</title>
  </head>
<body>
    <?php include('includes/header.php');?>
    <?php   
$user_id = $_SESSION['user_id'];
$product= mysqli_query($conn,"SELECT *
FROM users_items
INNER JOIN items ON users_items.item_id = items.item_id WHERE users_items.users_id = '$user_id' AND users_items.status='Added to cart'");
 if(mysqli_num_rows($product) == 0) {
   echo "<script>
      alert('Add items to the cart first');
      window.location.href='/home.php';
      </script>";
 }
else {
  echo  '<div class="container" style="margin-top: 40px; width:33%">
      <table class="table table-responsive table-hover">
    <thead>
      <tr>
        <th>Item Number</th>
        <th>Item Name</th>
        <th>Price</th>
          <th></th>
      </tr>
    </thead>
    <tbody>';
    $sum = 0;
    while($row = mysqli_fetch_assoc($product)){
        $sum = $sum + $row['price'];
    echo '<tr><td>'.$row['item_id'].'</td><td>'.$row['name'].'</td><td>'.$row['price'].'</td><td>';
        echo "<a href='cart-remove.php?id={$row['item_id']}'>Remove</a></td></tr>";}
    echo '<tr class="active">
        <td></td>
        <td>Total</td>
        <td>'.$sum.'</td>
          <td>';
        echo "<a class='btn btn-primary' href='success.php?id=$user_id'>Confirm Order</a></td>
      </tr>
    </tbody>
  </table></div>";
}  
    ?>  
  </body>
</html>