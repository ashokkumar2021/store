<?php
include('includes/common.php');
?>
<?php 
$item_id = $_GET['id'];
$user_id = $_SESSION['user_id'];
    $remove = mysqli_query($conn,"DELETE FROM users_items WHERE users_id='$user_id' AND item_id='$item_id'");
    header('location: cart.php');
?>