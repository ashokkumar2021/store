<?php include('includes/common.php');?>
<?php if(!isset($_SESSION{'email'})){
    header('location:index.php');
}?>
<?php include('setting_script.php');?>
<!DOCTYPE html>
<html>
  <head>
      <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
    <!--jQuery library--> 
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!--Latest compiled and minified JavaScript--> 
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>setting</title>
  </head>
<body>
   <?php include('includes/header.php');?>
    <div class="container" style="margin-top: 40px; width:33%">
      <h3><strong>Change Password</strong></h3>
        <form action="settings.php" method="post">
         <div class="form-group"><span class="text-danger"><?php if(isset($message)){echo $message;}?></span><span class="text-danger"><?php if(isset($match_error)){echo $match_error;}?></span>
      <input type="password" class="form-control" id="pwd" placeholder="Old Password" name="old_pwd" required>
    </div>
    <div class="form-group">
      <input type="password" class="form-control" id="pwd" placeholder="New Password" name="pwd_1" required>
    </div>
               <div class="form-group">
      <input type="password" class="form-control" id="pwd" placeholder="Re-type New Password" name="pwd_2" required>
    </div>
         <button type="submit" class="btn btn-primary" name="changepwd">Change</button>
            </form>
</div>

  </body>
</html>