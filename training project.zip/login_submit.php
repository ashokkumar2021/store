<?php include("includes/common.php"); ?>
<?php 
if (isset($_POST['login_user'])) {
     $email = mysqli_real_escape_string($conn, $_POST['email']);
     $password = mysqli_real_escape_string($conn, $_POST['pwd']);
    $password = md5($password);
  	$query = "SELECT * FROM users WHERE email='$email' AND password='$password'";
  	$results = mysqli_query($conn, $query);
      $row = mysqli_fetch_array($results);
  	if (mysqli_num_rows($results) == 1) {
        $_SESSION['email'] = $row['email'];
        $_SESSION['user_id'] = $row['id'];
        unset($_SESSION['error']);
  	  header('location: home.php');
  	}else {
  		$login_error = "please enter correct login details";
        $_SESSION['login'] = $email;
        $_SESSION['error'] = $login_error;
        header('location:index.php');
  	}
  }
?>